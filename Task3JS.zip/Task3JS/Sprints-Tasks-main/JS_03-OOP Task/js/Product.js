


// here we have created javascript class objects for product class

class Product 

{

  #_NameProduct;
  #_image;
  #_Price;

  constructor(NameProduct, image, Price) {
    this.#_NameProduct = NameProduct;
    
    this.#_Price = Price;
	
	this.#_image = image;
  }

  get NameProduct() {
    return this.#_NameProduct;
  }

  set NameProduct(newNameProduct) {
    this.#_NameProduct = newNameProduct;
  }

  get image() {
    return this.#_image;
  }

  set image(newImage) {
    return this.#_image;
  } 

  get Price() {
    return this.#_Price;
  }

  set Price(newPrice) {
    this.#_Price = newPrice;
  }
}